from pyspark.sql import SparkSession, Window
from pyspark.sql.functions import col, row_number

import os
import sys


if os.path.exists('src.zip'):
    sys.path.insert(0, 'src.zip')
else:
    sys.path.insert(0, './Code/src')

from src.utilities import utils


class USVehicleAccidentAnalysis:
    def __init__(self, path_to_config_file):
        input_file_paths = utils.read_yaml(path_to_config_file).get("INPUT_FILENAME")
        self.df_charges = utils.load_csv_data_to_df(spark, input_file_paths.get("Charges"))
        self.df_damages = utils.load_csv_data_to_df(spark, input_file_paths.get("Damages"))
        self.df_endorse = utils.load_csv_data_to_df(spark, input_file_paths.get("Endorse"))
        self.df_primary_person = utils.load_csv_data_to_df(spark, input_file_paths.get("Primary_Person"))
        self.df_units = utils.load_csv_data_to_df(spark, input_file_paths.get("Units"))
        self.df_restrict = utils.load_csv_data_to_df(spark, input_file_paths.get("Restrict"))

    def count_male_acc(self, output_path, output_format):
        """
        Find the number of crashes (accidents) in which number of males killed are greater than 2?
        :param output_path: output file path
        :param output_format: Write file format
        :return: dataframe count
        """
        df = self.df_primary_person.filter(self.df_primary_person.PRSN_GNDR_ID == "MALE") \
        .filter(col("PRSN_INJRY_SEV_ID") == "KILLED")
        #utils.write_output(df, output_path, output_format)
        return df.count()

    def count_2wheeler_accidents(self, output_path, output_format):
        """
        How many two wheelers are booked for crashes?
        :param output_format: Write file format
        :param output_path: output file path
        :return: dataframe count
        """
        df = self.df_units.filter(col("VEH_BODY_STYL_ID").contains("MOTORCYCLE"))
        #utils.write_output(df, output_path, output_format)

        return df.count()

    def state_with_highest_not_female_accident(self, output_path, output_format):
        """
        Which state has highest number of accidents in which females are not involved
        :param output_format: Write file format
        :param output_path: output file path
        :return: state name with highest accidents where female not involved
        """
        df = self.df_primary_person.filter(self.df_primary_person.PRSN_GNDR_ID != "FEMALE"). \
            groupby("DRVR_LIC_STATE_ID").count(). \
            orderBy(col("count").desc())
        #utils.write_output(df, output_path, output_format)

        return df.first().DRVR_LIC_STATE_ID

    def top_5_makers(self, output_path, output_format):
        """
        Determine the Top 5 Vehicle Makes of the cars present in the crashes in which driver died and Airbags did not deploy.
        :param output_format: Write file format
        :param output_path: output file path
        :return: the Top 5 Vehicle Makes of the cars present in the crashes in which driver died and Airbags did not deploy.
        """
        df = self.df_units.join(self.df_primary_person, on=['CRASH_ID'], how='inner') \
            .filter(col("VEH_MAKE_ID")!='NA')\
            .filter(col("PRSN_AIRBAG_ID").contains("NOT DEPLOYED")).filter(col("PRSN_INJRY_SEV_ID")=="KILLED").filter(col("PRSN_TYPE_ID")=="DRIVER") \
            .groupby("VEH_MAKE_ID").count(). \
            orderBy(col("count").desc()).limit(5)
        #utils.write_output(df, output_path, output_format)
        #df.coalesce(1).write.format("csv").mode('overwrite').option("header", "true").save(output_path)

        return [row[0] for row in df.collect()]

    def no_of_vechicles(self, output_path, output_format):
        """
        Determine number of Vehicles with driver having valid licences involved in hit and run?
        :param output_format: Write file format
        :param output_path: output file path
        :return: number of Vehicles with driver having valid licences involved in hit and run?
        """
        df = self.df_units.join(self.df_primary_person, on=['CRASH_ID'], how='inner') \
            .filter(col("VEH_HNR_FL")=="Y").filter(
            col("DRVR_LIC_TYPE_ID").contains("DRIVER")).filter(col("PRSN_TYPE_ID")=="DRIVER") \

        # utils.write_output(df, output_path, output_format)

        return df.select("VEH_MAKE_ID").count()

    def top_vehicle_contributing_to_injuries(self, output_path, output_format):
        """
        Which are the Top 3rd to 5th VEH_MAKE_IDs that contribute to a largest number of injuries including death
        :param output_format: Write file format
        :param output_path: output file path
        :return: Which are the Top 3rd to 5th VEH_MAKE_IDs that contribute to a largest number of injuries including death
        """
        df = self.df_units.filter(self.df_units.VEH_MAKE_ID != "NA"). \
            withColumn('TOT_CASUALTIES_CNT', self.df_units[35] + self.df_units[36]). \
            groupby("VEH_MAKE_ID").sum("TOT_CASUALTIES_CNT"). \
            withColumnRenamed("sum(TOT_CASUALTIES_CNT)", "TOT_CASUALTIES_CNT_AGG"). \
            orderBy(col("TOT_CASUALTIES_CNT_AGG").desc())

        df_top_3_to_5 = df.limit(5).subtract(df.limit(2))
        #utils.write_output(df_top_3_to_5, output_path, output_format)

        return [veh[0] for veh in df_top_3_to_5.select("VEH_MAKE_ID").collect()]


    def get_top_ethnic(self, output_path, output_format):
        """
        For all the body styles involved in crashes, mention the top ethnic user group of each unique body
        param output_format: Write file format
        :param output_path: output file path
        :return:  top ethnic user group
        """
        w = Window.partitionBy("VEH_BODY_STYL_ID").orderBy(col("count").desc())
        df = self.df_units.join(self.df_primary_person, on=['CRASH_ID'], how='inner'). \
            filter(~self.df_units.VEH_BODY_STYL_ID.isin(["NA", "UNKNOWN", "NOT REPORTED",
                                                         "OTHER  (EXPLAIN IN NARRATIVE)"])). \
            filter(~self.df_primary_person.PRSN_ETHNICITY_ID.isin(["NA", "UNKNOWN"])). \
            groupby("VEH_BODY_STYL_ID", "PRSN_ETHNICITY_ID").count(). \
            withColumn("row", row_number().over(w)).filter(col("row") == 1).drop("row", "count")

        #utils.write_output(df, output_path, output_format)

        return df.show(truncate=False)

    def get_top_5_zip_codes(self, output_path, output_format):
        """
        Finds top 5 Zip Codes with the highest number crashes with alcohols as the contributing factor to a crash
        :param output_format: Write file format
        :param output_path: output file path
        :return: List of Zip Codes
        """
        df = self.df_units.join(self.df_primary_person, on=['CRASH_ID'], how='inner'). \
            dropna(subset=["DRVR_ZIP"]). \
            filter(col("CONTRIB_FACTR_1_ID").contains("ALCOHOL") | col("CONTRIB_FACTR_2_ID").contains("ALCOHOL")). \
            groupby("DRVR_ZIP").count().orderBy(col("count").desc()).limit(5)
        #utils.write_output(df, output_path, output_format)

        return [row[0] for row in df.collect()]

    def get_crash_ids_with_no_damage(self, output_path, output_format):
        """
        Counts Distinct Crash IDs where No Damaged Property was observed and Damage Level (VEH_DMAG_SCL~) is above 4
        and car avails Insurance.
        :param output_format: Write file format
        :param output_path: output file path
        :return: List of crash ids
        """
        df = self.df_damages.join(self.df_units, on=["CRASH_ID"], how='inner'). \
            filter(
            (
                    (self.df_units.VEH_DMAG_SCL_1_ID > "DAMAGED 4") &
                    (~self.df_units.VEH_DMAG_SCL_1_ID.isin(["NA", "NO DAMAGE", "INVALID VALUE"]))
            ) | (
                    (self.df_units.VEH_DMAG_SCL_2_ID > "DAMAGED 4") &
                    (~self.df_units.VEH_DMAG_SCL_2_ID.isin(["NA", "NO DAMAGE", "INVALID VALUE"]))
            )
        ). \
            filter(self.df_damages.DAMAGED_PROPERTY == "NONE"). \
            filter(self.df_units.FIN_RESP_TYPE_ID == "PROOF OF LIABILITY INSURANCE")
        #utils.write_output(df, output_path, output_format)

        return [row[0] for row in df.collect()]

    def get_top_5_vehicle_brand(self, output_path, output_format):
        """
        Determines the Top 5 Vehicle Makes/Brands where drivers are charged with speeding related offences, has licensed
        Drivers, uses top 10 used vehicle colours and has car licensed with the Top 25 states with highest number of
        offences
        :param output_format: Write file format
        :param output_path: output file path
        :return List of Vehicle brands
        """
        top_25_state_list = [row[0] for row in self.df_units.filter(col("VEH_LIC_STATE_ID").cast("int").isNull()).
            groupby("VEH_LIC_STATE_ID").count().orderBy(col("count").desc()).limit(25).collect()]
        top_10_used_vehicle_colors = [row[0] for row in self.df_units.filter(self.df_units.VEH_COLOR_ID != "NA").
            groupby("VEH_COLOR_ID").count().orderBy(col("count").desc()).limit(10).collect()]

        df = self.df_charges.join(self.df_primary_person, on=['CRASH_ID'], how='inner'). \
            join(self.df_units, on=['CRASH_ID'], how='inner'). \
            filter(self.df_charges.CHARGE.contains("SPEED")). \
            filter(self.df_primary_person.DRVR_LIC_TYPE_ID.isin(["DRIVER LICENSE", "COMMERCIAL DRIVER LIC."])). \
            filter(self.df_units.VEH_COLOR_ID.isin(top_10_used_vehicle_colors)). \
            filter(self.df_units.VEH_LIC_STATE_ID.isin(top_25_state_list)). \
            groupby("VEH_MAKE_ID").count(). \
            orderBy(col("count").desc()).limit(5)

        #utils.write_output(df, output_path, output_format)

        return [row[0] for row in df.collect()]


if __name__ == '__main__':
    # Initialize sparks session
    spark = SparkSession \
        .builder \
        .appName("USVehicleAccidentAnalysis") \
        .getOrCreate()

    config_file_path = "config.yaml"
    spark.sparkContext.setLogLevel("ERROR")


    casestudy = USVehicleAccidentAnalysis(config_file_path)
    output_file_paths = utils.read_yaml(config_file_path).get("OUTPUT_PATH")
    file_format = utils.read_yaml(config_file_path).get("FILE_FORMAT")

    print("1. Find the number of crashes (accidents) in which number of males killed are greater than 2?")
    print("Result:", casestudy.count_male_acc(output_file_paths.get(1), file_format.get("Output")))

    print("2. How many two wheelers are booked for crashes?")
    print("Result:", casestudy.count_2wheeler_accidents(output_file_paths.get(2), file_format.get("Output")))

    print("3. Determine the Top 5 Vehicle Makes of the cars present in the crashes in which driver died and Airbags did not deploy.")
    print("Result:", casestudy.top_5_makers(output_file_paths.get(3), file_format.get("Output")))

    print("4. Determine number of Vehicles with driver having valid licences involved in hit and run?")
    print("Result:", casestudy.no_of_vechicles(output_file_paths.get(4), file_format.get("Output")))


    print("5. Which state has highest number of accidents in which females are not involved")
    print("Result:", casestudy.state_with_highest_not_female_accident(output_file_paths.get(5),
                                                                     file_format.get("Output")))

    print("6. Which are the Top 3rd to 5th VEH_MAKE_IDs that contribute to a largest number of injuries including death")
    print("Result:", casestudy.top_vehicle_contributing_to_injuries(output_file_paths.get(6),
                                                                       file_format.get("Output")))

    print("7. For all the body styles involved in crashes, mention the top ethnic user group of each unique body style")
    print("Result:")
    casestudy.get_top_ethnic(output_file_paths.get(7), file_format.get("Output"))

    print("8. Among the crashed cars, what are the Top 5 Zip Codes with highest number crashes with alcohols as the contributing factor to a crash (Use Driver Zip Code)")
    print("Result:", casestudy.get_top_5_zip_codes(output_file_paths.get(8),file_format.get("Output")))


    print('''9. Count of Distinct Crash IDs where No Damaged Property was observed and Damage Level (VEH_DMAG_SCL~) is above 4
    and car avails Insurance''')
    print("Result:", casestudy.get_crash_ids_with_no_damage(output_file_paths.get(9), file_format.get("Output")))

    print('''10. Determine the Top 5 Vehicle Makes where drivers are charged with speeding related offences, has licensed Drivers,
    used top 10 used vehicle colours and has car licensed with the Top 25 states with highest number of offences
    (to be deduced from the data)''')
    print("Result:", casestudy.get_top_5_vehicle_brand(output_file_paths.get(10), file_format.get("Output")))

    spark.stop()
